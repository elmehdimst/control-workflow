
> Note: `VM nbr` is the index of the VM created for a given OS, Test.  To avoid choosing random numbers, a dedicated range is assigned for each category of test.  When the VM nbr value is empty, it means that you have to decide a range, and update the the README page accordingly.  This range of index simplifies the identification of VMs created per OS and per category of tests.  (Used as value of the object_index in the tf script - ex. object_index = "250")
> 

> Note: To avoid duplicate the script, we use `for_each` to iterate over a list of VM arguments targetting the features to be tested.  Each *.tf file under this folder focus on a given feature to be tested:  Auto_Shutdown, availability_zone, Desaster Recovery (Dr), image templates, vm_sizes.
The features to be tested are defined as a list of objects in the locals section as illustrated in the following example
> 
```python
locals {
  vmtypes  = {
    "AvailZoneLin1" = {"os_type" = "Linux","image_template" = "RHEL8_Mutable",  "availability_zones" = "1,2", "vm_index" = "382"},
    "AvailZoneLin2" = {"os_type" = "Linux", "image_template" = "RHEL8_Mutable", "availability_zones" = "3,2", "vm_index" = "383"},
    "AvailZoneWin3" = {"os_type" = "Windows","image_template" = "Windows_2019_Mutable",  "availability_zones" = "1,2", "vm_index" = "282"},
    "AvailZoneWin4" = {"os_type" = "Windows", "image_template" = "Windows_2019_Mutable", "availability_zones" = "3,2", "vm_index" = "283"}
  }
}  

for_each = local.vmtypes
    object_index           = each.value.vm_index
    os_type                = each.value.os_type
    image_template         = each.value.image_template
    availability_zones     = each.value.availability_zones
    ...
```

|OS| Test|VM nbr|
|---|---|---|
| Windows | Additional disk | 200-201 |
| Windows | Data Storage Account | 202-206 |
| Windows | OS Storage Account | 207-211 |
| Windows | Encryption | 212-213 |
| Windows | VM Size |  214-215 |
| Windows | Hyper V Generation|  |
| Linux | Additional disk | 300-301 |
| Linux | Data Storage Account | 302-306 |
| Linux | OS Storage Account | 307-311 |
| Linux | Encryption | 312-313 |
| Linux | VM Size | 314-315 |
| Linux | Hyper V Generation |  |
