
> Note: `VM nbr` is the index of the VM created for a given OS, Test.  To avoid choosing random numbers, a dedicated range is assigned for each category of test.)
> 
> Note: To avoid duplicate the script, we use `for_each` to iterate over a list of VM arguments targetting the features to be tested.  Each *.tf file under this folder focus on a given feature to be tested:  Auto_Shutdown, availability_zone, Desaster Recovery (Dr), image templates, vm_sizes.
The features to be tested are defined as a list of objects in the locals section as illustrated in the following example
> 
```python
locals{
  OsTypes = [
    {"os"="Linux","image"="RHEL8_Mutable","prefix"="34"},
    {"os"="Windows","image"="Windows_2019_Mutable","prefix"="24"}]
}
locals{
  policies = [{"suffix"="0","policy"="none"},{"suffix"="1","policy"="light"},{"suffix"="2","policy"="basic"},{"suffix"="3","policy"="medium"},{"suffix"="4","policy"="intermediate"},{"suffix"="5""policy"="intermediate""enhanced"}]
}
locals {
  policiestypes = flatten(
    [ for o in local.OsTypes : [
          for po in local.policies: {
            "os_type" = o.os
            "image_template" = o.image
            "vm_backuppolicy" = po.policy
            "vm_index" = "${o.prefix}${po.suffix}"
          }
          ]
        ]
  )
}
# Once flattened, the pliciestypes list will have 12 elements as following:
  /*
    {"os_type" = "Linux","image_template" = "RHEL8_Mutable",  "vm_backuppolicy" = "none", "vm_index" = "240"}, 
    {"os_type" = "Linux", "image_template" = "RHEL8_Mutable", "vm_backuppolicy" = "light", "vm_index" = "241"},
    {"os_type" = "Linux", "image_template" = "RHEL8_Mutable", "vm_backuppolicy" = "basic", "vm_index" = "242"},
    {"os_type" = "Linux", "image_template" = "RHEL8_Mutable", "vm_backuppolicy" = "medium", "vm_index" = "243"},
    {"os_type" = "Linux", "image_template" = "RHEL8_Mutable", "vm_backuppolicy" = "intermediate", "vm_index" = "244"},
    {"os_type" = "Linux", "image_template" = "RHEL8_Mutable", "vm_backuppolicy" = "enhanced", "vm_index" = "245"},
    {"os_type" = "Windows","image_template" = "Windows_2019_Mutable",  "vm_backuppolicy" = "none", "vm_index" = "340"},
    {"os_type" = "Windows","image_template" = "Windows_2019_Mutable",  "vm_backuppolicy" = "light", "vm_index" = "341"},
    {"os_type" = "Windows","image_template" = "Windows_2019_Mutable",  "vm_backuppolicy" = "basic", "vm_index" = "342"},
    {"os_type" = "Windows","image_template" = "Windows_2019_Mutable",  "vm_backuppolicy" = "medium", "vm_index" = "343"},
    {"os_type" = "Windows","image_template" = "Windows_2019_Mutable",  "vm_backuppolicy" = "intermediate", "vm_index" = "344"},
    {"os_type" = "Windows","image_template" = "Windows_2019_Mutable",  "vm_backuppolicy" = "enhanced", "vm_index" = "345"}
  ]
  }
  */
module "nrtest_backup_policies" {
  # use map instead of duplicate code
  for_each = local.policiestypes
    object_index        = each.value.vm_index
    vm_backuppolicy     = each.value.vm_backuppolicy
    image_template      = each.value.image_template
    os_type             = each.value.os_type
    ...
```



| OS|Test |VM nbr|
|---|---|---|
| Windows| Backup Policies  | 240-245 |
| Linux| Backup Policies  | 340-345 |
