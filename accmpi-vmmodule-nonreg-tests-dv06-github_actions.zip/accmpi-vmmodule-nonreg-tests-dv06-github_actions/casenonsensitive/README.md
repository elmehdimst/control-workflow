> Note: `VM nbr` is the index of the VM created for a given OS, Test.  To avoid choosing random numbers, a dedicated range is assigned for each category of test.  When the VM nbr value is empty, it means that you have to decide a range, and update the the README page accordingly.  This range of index simplifies the identification of VMs created per OS and per category of tests.  (Used as value of the object_index in the tf script - ex. object_index = "250")
> 
|OS| Test |VM nbr|
|---|---|---|
| Windows | Custom Tags | 250 |
| Linux | Custom Tags | 350 |
