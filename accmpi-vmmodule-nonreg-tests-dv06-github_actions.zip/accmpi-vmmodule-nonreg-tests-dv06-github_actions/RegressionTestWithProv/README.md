# accmpi-vmmodule-nonreg-dev06
Summary of regression tests


| Test Case|Description |Source file|Last run|Result|
|---|---|---|---|---|
| VM-L1|Test simple VM Linux |[simple VM Linux](https://github.axa.com/ago-azurecc/accmpi-vmmodule-nonreg-tests-dv06/blob/github_actions/RegressionTestWithProv/SimpleVM.tf)|[Last run](https://github.axa.com/ago-azurecc/accmpi-vmmodule-nonreg-tests-dv06/actions/runs/62132)|[Last Evalutation](https://github.axa.com/ago-azurecc/accmpi-vmmodule-nonreg-tests-dv06/runs/192989?check_suite_focus=true)
